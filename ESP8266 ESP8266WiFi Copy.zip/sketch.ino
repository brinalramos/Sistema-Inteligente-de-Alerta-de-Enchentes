#if defined(ESP8266)
  #include <ESP8266WiFi.h>
#elif defined(ESP32)
  #include <WiFi.h>
#endif

#include <PubSubClient.h>

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""

const char* mqtt_server = "192.168.0.105";
const int mqtt_port = 1884;

WiFiClient espClient;
PubSubClient client(espClient);

#define LED 2
#define TRIG 5
#define ECHO 4
#define BUZZER 18

long duration;
float distance;

void InitWiFi(){
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED){
    delay(500);
  }
}

void reconnectWiFi(){
  if (WiFi.status() != WL_CONNECTED){
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED){
      delay(500);
    }
  }
}

void reconnectMQTT(){
  while (!client.connected()) {
    client.connect("ESP32Client");
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED, OUTPUT);
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(BUZZER, OUTPUT);

  InitWiFi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  reconnectWiFi();

  if (!client.connected()) {
    reconnectMQTT();
  }

  client.loop();

  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  duration = pulseIn(ECHO, HIGH);
  distance = duration * 0.034 / 2;

  Serial.println(distance);

  if (distance > 0 && distance < 20) {
    digitalWrite(LED, HIGH);
    digitalWrite(BUZZER, HIGH);
    client.publish("alarme", "ALERTA: movimento detectado");
  } else {
    digitalWrite(LED, LOW);
    digitalWrite(BUZZER, LOW);
  }

  delay(1000);
}