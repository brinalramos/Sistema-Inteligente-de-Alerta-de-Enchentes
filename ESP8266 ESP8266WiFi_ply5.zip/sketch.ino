#include <WiFi.h>
#include <PubSubClient.h>

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""

const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

WiFiClient espClient;
PubSubClient client(espClient);

#define LED 2
#define TRIG 5
#define ECHO 4
#define BUZZER 18

long duration;
float distance;

const int buzzerChannel = 0;

void InitWiFi() {
  Serial.print("Conectando ao WiFi");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado!");
}

void reconnectWiFi() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Reconectando WiFi...");

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED) {
      delay(500);
      Serial.print(".");
    }

    Serial.println();
    Serial.println("WiFi reconectado!");
  }
}

void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("Conectando ao MQTT...");

    if (client.connect("ESP32_Enchente")) {
      Serial.println(" conectado!");
    } else {
      Serial.print(" falhou. Código: ");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void ligarBuzzer() {
  ledcWriteTone(buzzerChannel, 1000);
}

void desligarBuzzer() {
  ledcWriteTone(buzzerChannel, 0);
}

void setup() {
  Serial.begin(115200);

  pinMode(LED, OUTPUT);
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);

  ledcAttach(BUZZER, 2000, 8);

  InitWiFi();

  client.setServer(mqtt_server, mqtt_port);

  Serial.println("Sistema Inteligente de Alerta de Enchentes");
}

void loop() {

  reconnectWiFi();

  if (!client.connected()) {
    reconnectMQTT();
  }

  client.loop();

  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG, LOW);

  duration = pulseIn(ECHO, HIGH);
  distance = duration * 0.034 / 2;

  Serial.print("Distancia: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (distance > 100) {

    digitalWrite(LED, LOW);
    desligarBuzzer();

    Serial.println("Nivel da agua normal");

    client.publish(
      "enchente/alerta",
      "Nivel da agua normal"
    );
  }
  else if (distance >= 20 && distance <= 100) {

    digitalWrite(LED, HIGH);
    desligarBuzzer();

    Serial.println("ATENCAO: nivel da agua aumentando");

    client.publish(
      "enchente/alerta",
      "ATENCAO: nivel da agua aumentando"
    );
  }
  else {

    digitalWrite(LED, HIGH);
    ligarBuzzer();

    Serial.println("ALERTA DE ENCHENTE!");

    client.publish(
      "enchente/alerta",
      "ALERTA DE ENCHENTE - Nivel critico detectado"
    );
  }

  Serial.println("-----------------------");

  delay(2000);
}